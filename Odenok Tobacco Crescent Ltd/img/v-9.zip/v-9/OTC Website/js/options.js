function togglebExperienceDropdown() {
    const bExperienceOptions = document.getElementById('bExperienceOptions');
    bExperienceOptions.style.display = bExperienceOptions.style.display === 'block' ? 'none' : 'block';
}

function togglecriteriaDropdown() {
    const criteriaOptions = document.getElementById('CriteriaOptions');
    criteriaOptions.style.display = criteriaOptions.style.display === 'block' ? 'none' : 'block';
}

function togglebenifitsDropdown() {
    const benifitsOptions = document.getElementById('benifitsOptions');
    benifitsOptions.style.display = benifitsOptions.style.display === 'block' ? 'none' : 'block';
}

function togglefinalcialDropdown() {
    const finalcialOptions = document.getElementById('finalcialOptions');
    finalcialOptions.style.display = finalcialOptions.style.display === 'block' ? 'none' : 'block';
}